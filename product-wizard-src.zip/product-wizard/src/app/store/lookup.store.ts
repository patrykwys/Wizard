import { signalStore, withMethods, withProps } from '@ngrx/signals';
import { rxResource } from '@angular/core/rxjs-interop';
import { delay, Observable, of } from 'rxjs';
import { CategoryMatch, CategoryOption } from '../models/product.model';

/**
 * App-wide reference data for dropdowns. Options load once and are cached for
 * the lifetime of the app, so every page shares the same fetch.
 *
 * Mock data lives here so the demo runs without a backend. To go live, replace
 * each `of(...)` with an HttpClient call, or swap `rxResource` for
 * `httpResource(() => '/api/...')` — the component code does not change.
 */

interface CategoryNode {
  id: string;
  label: string;
  children?: CategoryNode[];
}

// Placeholder catalogue. The shape (3 cascading levels) matches the wizard;
// the contents are stand-ins for whatever the real API returns.
const CATEGORY_TREE: CategoryNode[] = [
  {
    id: 'l1-a',
    label: 'Domain A',
    children: [
      {
        id: 'l2-a1',
        label: 'Area A1',
        children: [
          { id: 'l3-a1x', label: 'Topic A1-X' },
          { id: 'l3-a1y', label: 'Topic A1-Y' },
        ],
      },
      {
        id: 'l2-a2',
        label: 'Area A2',
        children: [{ id: 'l3-a2x', label: 'Topic A2-X' }],
      },
    ],
  },
  {
    id: 'l1-b',
    label: 'Domain B',
    children: [
      {
        id: 'l2-b1',
        label: 'Area B1',
        children: [{ id: 'l3-b1x', label: 'Topic B1-X' }],
      },
    ],
  },
];

const PRODUCT_TYPES = ['Dashboard', 'Report', 'Dataset', 'Model'];
const OWNERSHIP_OPTIONS = ['Team', 'Department', 'Individual', 'Shared'];
const SOURCE_KINDS = ['Tableau', 'PowerBI', 'ServiceNow', 'Collibra', 'Other'];

const LATENCY = 250;

function findNode(nodes: CategoryNode[], id: string): CategoryNode | undefined {
  for (const node of nodes) {
    if (node.id === id) {
      return node;
    }
    const hit = node.children && findNode(node.children, id);
    if (hit) {
      return hit;
    }
  }
  return undefined;
}

function toOptions(nodes: CategoryNode[] | undefined): CategoryOption[] {
  return (nodes ?? []).map((n) => ({ id: n.id, label: n.label }));
}

function searchLeaves(query: string): CategoryMatch[] {
  const needle = query.trim().toLowerCase();
  const out: CategoryMatch[] = [];
  const walk = (nodes: CategoryNode[], trail: string[]): void => {
    for (const node of nodes) {
      const path = [...trail, node.label];
      if (node.children?.length) {
        walk(node.children, path);
      } else if (
        needle === '' ||
        node.label.toLowerCase().includes(needle) ||
        node.id.toLowerCase().includes(needle)
      ) {
        out.push({ id: node.id, path });
      }
    }
  };
  walk(CATEGORY_TREE, []);
  return out;
}

export const LookupStore = signalStore(
  { providedIn: 'root' },
  withProps(() => ({
    // Flat lists: loaded once, shared everywhere. `defaultValue` keeps
    // `.value()` non-undefined so templates stay clean.
    productTypes: rxResource<string[], void>({
      defaultValue: [],
      stream: () => of(PRODUCT_TYPES).pipe(delay(LATENCY)),
    }),
    ownership: rxResource<string[], void>({
      defaultValue: [],
      stream: () => of(OWNERSHIP_OPTIONS).pipe(delay(LATENCY)),
    }),
    sourceKinds: rxResource<string[], void>({
      defaultValue: [],
      stream: () => of(SOURCE_KINDS).pipe(delay(LATENCY)),
    }),
    categoryRoots: rxResource<CategoryOption[], void>({
      defaultValue: [],
      stream: () => of(toOptions(CATEGORY_TREE)).pipe(delay(LATENCY)),
    }),
  })),
  withMethods(() => ({
    // Cascade + search are parameterised, so components drive them through
    // their own rxResource keyed off the selected parent / query.
    categoryChildren(parentId: string): Observable<CategoryOption[]> {
      const node = findNode(CATEGORY_TREE, parentId);
      return of(toOptions(node?.children)).pipe(delay(LATENCY));
    },
    searchCategories(query: string): Observable<CategoryMatch[]> {
      return of(searchLeaves(query)).pipe(delay(LATENCY));
    },
  })),
);
