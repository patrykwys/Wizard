# Product registration wizard

A 6-page wizard built on **Angular 22**, **NgRx Signal Store v21** (events, entities,
custom features) and the experimental **Signal Forms** API. Compiles clean under
`strict` + `strictTemplates`.

## Run

```bash
npm install --legacy-peer-deps   # NgRx 21 has no Angular 22 peer entry yet
ng serve
```

> `--legacy-peer-deps` is only needed until `@ngrx/signals` v22 ships.

## How the pieces fit

**One store, three responsibilities, kept separate.** Signal Forms own per-field
value/validity/touched/dirty. The store owns the canonical merged draft, wizard
navigation, the repeatable sources collection, and persistence. They meet at one
seam: the model signal each page binds its `form()` to.

```
store/
  wizard.events.ts              # typed event inventory (the "what can happen")
  product-draft.store.ts        # composes features + reducer + autosave handler
  features/
    with-wizard-navigation.ts   # currentPage, completedPages, progress, next/prev/goTo
    with-draft-persistence.ts   # hydrate-on-init, persistNow, clearStorage
```

**Events, not method calls, drive state.** Pages dispatch (`injectDispatch`);
`withReducer(on(...))` turns events into state. `withEventHandlers` runs the one
real side effect: debounced autosave to `localStorage`, and clears storage on
reset. Pure navigation stays as plain methods because it has no side effects.

**Entities for the repeatable collection.** Sources are a keyed entity collection
(`withEntities` + `entityConfig`), committed as a whole array via `setAllEntities`.

**The linkedSignal decision (the interesting bit).** Object-section pages
(basic/description/access/identify) use `linkedSignal(() => store.draft().section)`
as the writable working copy: it re-seeds if the store changes underneath
(hydrate completing, or jumping back from Review). This is loop-safe **only**
because the autosave reducer passes the section reference straight through
(`{ ...draft, ...payload }`), so the round-trip lands on the same object identity
and the linkedSignal does not re-emit.

The **sources** page deliberately uses a plain `signal`, not `linkedSignal`:
`sourcesEntities()` returns a fresh array reference on every read, so a
linkedSignal would re-seed -> fire the autosave effect -> re-seed forever. The
component is created on entry (after hydrate), so a one-time seed is correct.

**Autosave + reload survival.** Every section edit pushes into the store via one
`effect`; the store debounces and writes the full state snapshot to
`localStorage`; `onInit` rehydrates it (entities included). Close the tab
mid-edit, reopen, and you are where you left off.

## Notes / caveats

- Signal Forms is experimental; the binding directive is `[formField]` and field
  state is accessed by **calling** the field: `form.name().touched()`.
- Array fields (tags) are updated through the model (`model.update`), not via
  `[formField]`, per the Signal Forms constraints.
- The store + event scope are provided at the wizard **route**, not in root, so
  they die when you leave the wizard.

## Dropdown data (API-driven)

Option lists are server data, not draft state, so they live outside
`ProductDraftStore` in a root `LookupStore` (`store/lookup.store.ts`):

- Flat lists (type, ownership, source kind, level-1 categories) are
  `rxResource`s with `defaultValue: []` — loaded once, cached app-wide, shared
  by every page.
- The cascade (level 2/3) and search are parameterised, so each step drives its
  own `rxResource` keyed off the selected parent / query; changing the parent
  refetches automatically.

Mock data lives in `LookupStore` so the demo runs offline. To go live, replace
each `of(...)` with an `HttpClient` call or swap `rxResource` for
`httpResource(() => '/api/...')` — no component changes.

## Shared components

- `shared/field-error.ts` — `<app-field-error [field]="form.x" />`, generic over
  the field value type; replaces the repeated touched/errors markup.
- `shared/tag-input.ts` — presentational tag editor (`[tags]` in, `tagsChange`
  out); the form model stays the owner of the list.

## Identify cascade — selection is persisted

The level-1/level-2/leaf selection lives in `IdentifyData` (the draft), not in
local component signals. That is why it survives leaving/returning to the step
and a reload: on re-entry the working copy re-seeds from the store and the
dependent resources refetch from the restored ids.
