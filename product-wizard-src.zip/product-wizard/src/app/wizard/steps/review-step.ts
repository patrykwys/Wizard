import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { injectDispatch } from '@ngrx/signals/events';
import { ProductPage } from '../../models/product.model';
import { ProductDraftStore } from '../../store/product-draft.store';
import { wizardEvents } from '../../store/wizard.events';

@Component({
  selector: 'app-review-step',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './review-step.html',
})
export class ReviewStep {
  protected readonly store = inject(ProductDraftStore);
  private readonly dispatch = injectDispatch(wizardEvents);

  protected edit(page: ProductPage): void {
    this.store.goTo(page);
  }

  protected submit(): void {
    // A real app would POST here; on success, reset the wizard.
    this.dispatch.cleared();
  }
}
