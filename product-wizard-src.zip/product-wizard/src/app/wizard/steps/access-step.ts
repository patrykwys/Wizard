import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  linkedSignal,
} from '@angular/core';
import { form, FormField, required, submit } from '@angular/forms/signals';
import { injectDispatch } from '@ngrx/signals/events';
import { ProductDraftStore } from '../../store/product-draft.store';
import { wizardEvents } from '../../store/wizard.events';
import { FieldError } from '../../shared/field-error';
import { TagInput } from '../../shared/tag-input';

@Component({
  selector: 'app-access-step',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormField, FieldError, TagInput],
  templateUrl: './access-step.html',
})
export class AccessStep {
  private readonly store = inject(ProductDraftStore);
  private readonly dispatch = injectDispatch(wizardEvents);

  protected readonly model = linkedSignal(() => this.store.draft().access);

  // Fixed enums, not API lookups.
  protected readonly visibilities = ['private', 'internal', 'public'] as const;
  protected readonly classifications = [
    'public',
    'internal',
    'confidential',
    'restricted',
  ] as const;

  protected readonly accessForm = form(this.model, (p) => {
    required(p.visibility, { message: 'Choose a visibility' });
    required(p.classification, { message: 'Choose a classification' });
  });

  private readonly sync = effect(() => {
    this.dispatch.draftPatched({ access: this.model() });
  });

  protected setTags(tags: string[]): void {
    this.model.update((m) => ({ ...m, tags }));
  }

  protected next(): void {
    submit(this.accessForm, async () => {
      this.dispatch.pageCompleted('access');
      this.store.next();
    });
  }

  protected back(): void {
    this.store.prev();
  }
}
