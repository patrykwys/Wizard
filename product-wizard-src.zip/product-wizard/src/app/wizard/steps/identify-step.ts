import {
  ChangeDetectionStrategy,
  Component,
  effect,
  inject,
  linkedSignal,
  signal,
} from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { form, required, submit } from '@angular/forms/signals';
import { injectDispatch } from '@ngrx/signals/events';
import { CategoryMatch, CategoryOption } from '../../models/product.model';
import { LookupStore } from '../../store/lookup.store';
import { ProductDraftStore } from '../../store/product-draft.store';
import { wizardEvents } from '../../store/wizard.events';
import { FieldError } from '../../shared/field-error';

@Component({
  selector: 'app-identify-step',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FieldError],
  templateUrl: './identify-step.html',
})
export class IdentifyStep {
  private readonly store = inject(ProductDraftStore);
  private readonly lookups = inject(LookupStore);
  private readonly dispatch = injectDispatch(wizardEvents);

  // Working copy. The whole cascade selection lives in here (level1/level2/
  // selectedId), so it survives leaving/returning to the step and a reload.
  protected readonly model = linkedSignal(() => this.store.draft().identify);

  protected readonly identifyForm = form(this.model, (p) => {
    required(p.selectedId, { message: 'Select a category to continue' });
  });

  // Level 1 is shared/cached; levels 2-3 refetch when their parent changes.
  protected readonly roots = this.lookups.categoryRoots;
  protected readonly level2 = rxResource({
    defaultValue: [],
    params: () => this.model().level1 || undefined,
    stream: ({ params }) => this.lookups.categoryChildren(params),
  });
  protected readonly level3 = rxResource({
    defaultValue: [],
    params: () => this.model().level2 || undefined,
    stream: ({ params }) => this.lookups.categoryChildren(params),
  });

  // Search runs only after the button sets the term.
  protected readonly term = signal('');
  protected readonly results = rxResource({
    defaultValue: [],
    params: () => this.term() || undefined,
    stream: ({ params }) => this.lookups.searchCategories(params),
  });

  // One-directional autosave; pass-through ref keeps the linkedSignal loop-safe.
  private readonly sync = effect(() => {
    this.dispatch.draftPatched({ identify: this.model() });
  });

  protected onLevel1(id: string): void {
    this.model.update((m) => ({
      ...m,
      level1: id,
      level2: '',
      selectedId: '',
      selectedPath: [],
    }));
  }

  protected onLevel2(id: string): void {
    this.model.update((m) => ({
      ...m,
      level2: id,
      selectedId: '',
      selectedPath: [],
    }));
  }

  protected onLevel3(id: string): void {
    const path = [
      this.label(this.roots.value(), this.model().level1),
      this.label(this.level2.value(), this.model().level2),
      this.label(this.level3.value(), id),
    ];
    this.model.update((m) => ({ ...m, selectedId: id, selectedPath: path }));
  }

  protected updateQuery(value: string): void {
    this.model.update((m) => ({ ...m, query: value }));
  }

  protected search(): void {
    this.term.set(this.model().query);
  }

  protected pick(match: CategoryMatch): void {
    this.model.update((m) => ({
      ...m,
      selectedId: match.id,
      selectedPath: match.path,
    }));
  }

  protected next(): void {
    submit(this.identifyForm, async () => {
      this.dispatch.pageCompleted('identify');
      this.store.next();
    });
  }

  private label(options: CategoryOption[], id: string): string {
    return options.find((o) => o.id === id)?.label ?? '';
  }
}
